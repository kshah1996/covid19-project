library(covid)
library(testthat)

test_check("covid")
